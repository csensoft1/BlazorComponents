window.summerNoteJsInterop = {

    initialiseEditor: function (id, dotNetReference) {

        $('#' + id).summernote({
            toolbar: [
                ['style', ['bold', 'italic', 'underline', 'clear']],
                ['font', ['strikethrough', 'superscript', 'subscript']],
                ['para', ['ul', 'ol', 'paragraph']], 
                ['table', ['table']],
                ['insert', ['link', 'picture']],
                ['view', ['fullscreen', 'help']]
            ],
            height: 100,
            callbacks: {
                onChange: function (contents) {
                    dotNetReference.invokeMethodAsync('UpdateText', contents);
                }
            }

        });

  }

};
